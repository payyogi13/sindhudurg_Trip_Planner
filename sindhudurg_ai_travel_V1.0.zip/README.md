# Sindhudurg AI Travel Planner

This is a 3D beach-themed travel planner web app with Marathi UI slogan, dropdown cities, and animated wave loader.